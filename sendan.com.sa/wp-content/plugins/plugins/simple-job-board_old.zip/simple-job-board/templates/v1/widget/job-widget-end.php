<?php
/*
 * Widget Recent Jobs Wrapper End
 * 
 * * Override this template by copying it to yourtheme/simple_job_board/v1/widget/job-widget-end.php
 * 
 * @author      PressTigers
 * @package     Simple_Job_Board
 * @subpackage  Simple_Job_Board/templates/widget/job-widget-end.php
 * @version     1.0.0
 */
?>
</ul>