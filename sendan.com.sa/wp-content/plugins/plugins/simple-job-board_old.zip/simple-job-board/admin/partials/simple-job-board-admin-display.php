<?php
/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wordpress.org/plugins/simple-job-board
 *
 * @package    Simple_Job_Board
 * @subpackage Simple_Job_Board/admin/partials
 * @since      1.0.0
 */