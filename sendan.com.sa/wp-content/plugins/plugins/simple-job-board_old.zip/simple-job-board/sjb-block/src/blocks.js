/**
 * Gutenberg Blocks
 *
 * All blocks related JavaScript files should be imported here.
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 *
 * @since 2.8.0
 */

import './block/block.js';
